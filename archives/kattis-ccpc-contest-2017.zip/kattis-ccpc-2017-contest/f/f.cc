#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> ii;
typedef long long ll;


int main() {


   


   return 0;
}
